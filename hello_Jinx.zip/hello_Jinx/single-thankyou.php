<?php 
get_header();
?>
<div class='flx-thx convclass' id='convclass'>
<style>
.videosection { max-width: 800px; width: 100%; aspect-ratio: 16 / 9; }
</style>
    <div><h1>شكرا لك</h1></div>
    <span>جاري التواصل معك في اقرب فرصة</span>
</div>
<?php get_footer(); ?>
