<?php 
get_header();
?>
<div class='flx-thx convclass' id='convclass'>
<style>
.videosection { max-width: 800px; width: 100%; aspect-ratio: 16 / 9; }
</style>
    <div><h1>شكرا لك</h1></div>
    <span>جاري التواصل معك في اقرب فرصة</span>
    <div class='videosection'>
        <iframe width="100%" height="100%" src="https://www.youtube.com/embed/WbYbjIpCkSM?si=WzzptRmCoJPtygPD" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
    </div>
</div>
<?php get_footer(); ?>
