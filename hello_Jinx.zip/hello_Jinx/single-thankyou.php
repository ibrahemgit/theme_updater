<?php 
get_header();
?>
<div class='flx-thx convclass' id='convclass'>

    <div><h1>شكرا لك</h1></div>
    <span>جاري التواصل معك في اقرب فرصة</span>
</div>
<?php get_footer(); ?>
